Rolls Royce R211-524C for FS2002-FS2004

********************************************
********************************************

=================================================

All files by Devyn Silverstein 


--------------------------------------------------------------

Installation ---- Just extract the sounds into the sound folder of the aircraft 
of your choice.

A new, "Unreal" soundset for your 747-100s/200s/300s/SPs/ and L-1011s. I just couldn't sit this one out. Plug in your subs for this set. 

Enjoy the sounds


Devyn J. Silverstein
Devyn.Silverstein@gmail.com